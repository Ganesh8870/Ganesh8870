# SkillUp — SAP CPI + English (Android project)

A starter Android app tailored for 20 minutes/day of SAP CPI and English practice, with English + Tamil explanations.

## Included
- Offline lessons for grammar, sentence formation, SAP CPI concepts, reading, client communication, and interview preparation.
- Daily 20-minute plan.
- Saves typed answers and a simple completion count on the device.
- Optional online AI helper using a user-configured OpenAI-compatible `/v1/chat/completions` endpoint.
- No API key is bundled in the source.

## Build APK with Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder (`SkillUpAndroid`) in Android Studio.
3. Allow Gradle sync and install any prompted components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will usually be at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (after installing Android SDK and Gradle):
`gradle assembleDebug`

## AI setup
Open the AI tab and enter your provider's HTTPS chat-completions endpoint, model name, and API key. These values are stored in local app preferences. AI use may cost money depending on the provider. Do not enter company secrets, production payloads, credentials, or confidential client information.

This starter supports the common OpenAI-compatible chat-completions request/response shape. Providers with a different API format may not work without adaptation.

## Current limitations
- This is a starter project, not a Play Store release.
- Progress is a basic on-device completion count; it does not yet include cloud sync, reminders, secure key storage, or automatic spaced repetition.
- AI requires an internet connection and a compatible provider endpoint. Offline lessons remain available without AI.
- The debug APK is not signed for Play Store distribution.
