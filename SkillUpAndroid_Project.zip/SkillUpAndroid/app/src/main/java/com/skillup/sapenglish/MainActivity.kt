package com.skillup.sapenglish

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("skillup", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val navy = Color.rgb(24, 48, 78)
    private val blue = Color.rgb(42, 105, 170)
    private val pale = Color.rgb(241, 246, 251)
    private var activeTab = "Home"

    data class Lesson(val title: String, val category: String, val body: String, val tamil: String, val task: String)

    private val lessons = listOf(
        Lesson("Present simple", "English Grammar", "Use it for routines and facts. Example: I work with SAP CPI.", "வழக்கமாக நடக்கும் செயல்கள் அல்லது உண்மைகளுக்கு பயன்படுத்தவும்.", "Write one sentence about your daily work."),
        Lesson("Simple past", "English Grammar", "Use it for completed past actions. Example: I attended a client meeting yesterday.", "கடந்த காலத்தில் முடிந்த செயல்களுக்கு பயன்படுத்தவும்.", "Translate: நான் நேற்று ஒரு நேர்காணலில் கலந்து கொண்டேன்."),
        Lesson("Future with will", "English Grammar", "Use will + base verb. Example: I will complete the mapping tomorrow.", "எதிர்கால செயல்களுக்கு will + verb பயன்படுத்தவும்.", "Write one sentence about tomorrow."),
        Lesson("Ask a clear question", "English Grammar", "Use: Did you check the iFlow? / Could you share the payload?", "கேள்விகளை சுருக்கமாகவும் தெளிவாகவும் கேட்கவும்.", "Write a polite question for a client."),
        Lesson("If condition", "English Grammar", "If + present simple, will + verb. Example: If I get the job, I will join immediately.", "If பகுதி present tense; அடுத்த பகுதியில் will பயன்படுத்தலாம்.", "Complete: If I receive the payload, I will ___."),
        Lesson("What is an iFlow?", "SAP CPI", "An integration flow (iFlow) defines how a message moves between a sender and receiver. It can include adapters, mappings, routing, and exception handling.", "iFlow என்பது sender-இலிருந்து receiver-க்கு message செல்லும் integration process-ஐ வரையறுக்கிறது.", "Explain an iFlow in 2–3 English sentences."),
        Lesson("Message mapping", "SAP CPI", "Message mapping transforms a source message structure into a target structure. Validate mandatory fields and test with representative payloads.", "Source format-இல் உள்ள data-வை target format-க்கு மாற்றுகிறது.", "Name two things you validate in a mapping."),
        Lesson("Exception handling", "SAP CPI", "Use exception subprocesses and meaningful logs to handle errors. Avoid exposing passwords, tokens, or sensitive payload data in logs.", "பிழைகளை கையாள exception subprocess மற்றும் பாதுகாப்பான logs பயன்படுத்தவும்.", "How would you investigate a failed iFlow?"),
        Lesson("OAuth in API Management", "SAP CPI", "OAuth 2.0 supports token-based authorization. Keep client secrets secure and check scopes, token expiry, and policy configuration.", "Token மூலம் API அணுகலை கட்டுப்படுத்தும் முறைகளில் OAuth 2.0 ஒன்று.", "Name two checks when an API returns 401."),
        Lesson("Client-call update", "Communication", "Use this structure: what happened, impact, next action. Example: The message failed because the target endpoint returned 503. I am checking retries and will update you by 3 PM.", "என்ன நடந்தது, அதன் தாக்கம், அடுத்த நடவடிக்கை என மூன்று பகுதிகளாக பேசவும்.", "Give a short project status update."),
        Lesson("Article: Reliable integrations", "Reading", "Reliable integrations need clear monitoring, retries, and useful error messages. A retry can help with temporary failures, but repeated retries will not fix invalid data or incorrect credentials.", "நம்பகமான integration-க்கு monitoring, retry, தெளிவான error messages தேவை. தவறான data அல்லது credentials-ஐ retry மட்டும் சரிசெய்யாது.", "What is one problem that retry cannot fix?"),
        Lesson("Interview: Tell me about yourself", "Interview", "Use 3 parts: experience, core skills, and a project example. Keep the answer honest and under 60 seconds.", "அனுபவம், முக்கிய திறன்கள், project example ஆகிய மூன்றையும் சொல்லவும்.", "Draft your 3-part introduction.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.rgb(35, 45, 58))
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(2), dp(5), dp(2), dp(5))
        }
    }

    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(blue)
        setOnClickListener { action() }
    }

    private fun base(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply {
            text = title; textSize = 23f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = subtitle; textSize = 13f; setTextColor(Color.rgb(220, 232, 245))
        })
        root.addView(header)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            setBackgroundColor(pale); gravity = Gravity.CENTER
        }
        listOf("Home", "SAP CPI", "English", "Reading", "Interview", "AI").forEach { tab ->
            val b = TextView(this).apply {
                text = tab; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(if (activeTab == tab) blue else navy)
                setPadding(dp(5), dp(13), dp(5), dp(13))
                setOnClickListener { activeTab = tab; when(tab) {
                    "Home" -> showHome(); "SAP CPI" -> showCategory("SAP CPI")
                    "English" -> showCategory("English Grammar"); "Reading" -> showCategory("Reading")
                    "Interview" -> showCategory("Interview"); "AI" -> showAI()
                } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        // content is returned through a tagged reference
        root.tag = content
    }

    private fun content(): LinearLayout = root.tag as LinearLayout

    private fun card(title: String, body: String) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(pale)
        }
        c.addView(text(title, 17f, true))
        c.addView(text(body, 14f))
        val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(10)
        content().addView(c, p)
    }

    private fun showHome() {
        activeTab = "Home"
        base("SkillUp", "SAP CPI + English • 20-minute daily practice")
        val done = prefs.getInt("completed", 0)
        val streak = prefs.getInt("sessions", 0)
        content().addView(text("Your learning dashboard", 20f, true))
        card("Progress", "$done lessons completed • $streak practice sessions recorded")
        content().addView(button("Start today's 20-minute plan") {
            prefs.edit().putInt("sessions", streak + 1).apply()
            showDailyPlan()
        })
        card("Suggested plan", "5 min grammar • 5 min SAP CPI • 5 min reading/vocabulary • 5 min speaking or interview practice")
        card("Offline ready", "Lessons and exercises work without internet. AI explanations require internet and your own compatible API endpoint/key.")
        content().addView(button("Review all lessons") { showCategory("All") })
    }

    private fun showDailyPlan() {
        activeTab = "Home"
        base("Today's plan", "Four short activities")
        val plan = listOf(
            "1 • Grammar (5 min)" to lessons[1],
            "2 • SAP CPI (5 min)" to lessons[5],
            "3 • Reading (5 min)" to lessons[10],
            "4 • Communication (5 min)" to lessons[9]
        )
        plan.forEach { (heading, lesson) ->
            card(heading, lesson.title + "\n" + lesson.body + "\nதமிழ்: " + lesson.tamil + "\nPractice: " + lesson.task)
            content().addView(button("Open lesson: ${lesson.title}") { showLesson(lesson) })
        }
    }

    private fun showCategory(category: String) {
        activeTab = when(category) {
            "SAP CPI" -> "SAP CPI"; "English Grammar" -> "English"; "Reading" -> "Reading"; "Interview" -> "Interview"; else -> "Home"
        }
        base(if(category == "All") "All lessons" else category, "Read, practise, and mark lessons complete")
        val list = lessons.filter { category == "All" || it.category == category || (category == "English Grammar" && it.category == "Communication") }
        if (list.isEmpty()) content().addView(text("No lessons in this category yet."))
        list.forEach { l ->
            card(l.title, l.body)
            content().addView(button("Study this lesson") { showLesson(l) })
        }
        if (category == "English Grammar") {
            card("Sentence builder", "Use: Subject + verb + object. Example: I tested the iFlow. Past: I tested. Future: I will test.")
        }
    }

    private fun showLesson(l: Lesson) {
        base(l.title, l.category)
        content().addView(text(l.body, 17f))
        content().addView(text("தமிழ் விளக்கம்", 16f, true))
        content().addView(text(l.tamil, 15f))
        content().addView(text("Your practice", 16f, true))
        content().addView(text(l.task, 15f))
        val answer = EditText(this).apply { hint = "Type your answer here"; minLines = 2; gravity = Gravity.TOP; setTextColor(Color.BLACK) }
        content().addView(answer, LinearLayout.LayoutParams(-1, -2))
        content().addView(button("Save answer and mark complete") {
            val key = "answer_" + l.title.hashCode()
            prefs.edit().putString(key, answer.text.toString())
                .putInt("completed", prefs.getInt("completed", 0) + 1).apply()
            Toast.makeText(this, "Progress saved on this device", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content().addView(button("Ask AI to improve my answer") {
            askAI("Correct my English answer. Explain the most important mistakes in simple English and Tamil. Lesson: ${l.title}. Prompt: ${l.task}. My answer: ${answer.text}")
        })
    }

    private fun showAI(initialPrompt: String = "") {
        activeTab = "AI"
        base("AI learning helper", "Online feature • configure a compatible chat-completions API")
        content().addView(text("API endpoint", 15f, true))
        val endpoint = EditText(this).apply {
            hint = "https://your-provider.example/v1/chat/completions"
            setSingleLine(true); setText(prefs.getString("endpoint", ""))
        }
        content().addView(endpoint)
        content().addView(text("Model name", 15f, true))
        val model = EditText(this).apply { hint = "Model name from your provider"; setSingleLine(true); setText(prefs.getString("model", "")) }
        content().addView(model)
        content().addView(text("API key (stored locally on this device)", 15f, true))
        val apiKey = EditText(this).apply {
            hint = "Paste API key"; setSingleLine(true); inputType = 129
            setText(prefs.getString("api_key", ""))
        }
        content().addView(apiKey)
        content().addView(button("Save AI settings") {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("api_key", apiKey.text.toString()).apply()
            Toast.makeText(this, "Settings saved locally", Toast.LENGTH_SHORT).show()
        })
        content().addView(text("Ask about SAP CPI or English", 16f, true))
        val prompt = EditText(this).apply {
            hint = "Example: Explain exception subprocess in simple English and Tamil."
            minLines = 3; gravity = Gravity.TOP; setText(initialPrompt)
        }
        content().addView(prompt)
        val result = TextView(this).apply { textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, dp(10), 0, dp(10)) }
        content().addView(result)
        content().addView(button("Ask AI") {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim())
                .putString("model", model.text.toString().trim()).putString("api_key", apiKey.text.toString()).apply()
            result.text = "Connecting…"
            val p = prompt.text.toString().trim()
            thread {
                val response = callAI(p)
                runOnUiThread { result.text = response }
            }
        })
        card("Privacy and cost", "AI calls send your prompt to the API provider you configure and may incur charges. Do not send employer secrets, passwords, client payloads, or personal data. This starter stores the key in local app preferences; use a backend for stronger key protection.")
    }

    private fun askAI(prompt: String) {
        activeTab = "AI"
        showAI(prompt)
    }

    private fun callAI(prompt: String): String {
        val endpoint = prefs.getString("endpoint", "") ?: ""
        val model = prefs.getString("model", "") ?: ""
        val key = prefs.getString("api_key", "") ?: ""
        if (endpoint.isBlank() || model.isBlank() || key.isBlank())
            return "Please save your API endpoint, model name, and API key first. AI is optional; offline lessons still work."
        return try {
            val url = URL(endpoint)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $key")
            }
            val system = "You are a concise SAP CPI tutor and English coach. Explain technical concepts accurately. Use simple English and Tamil explanations. Correct grammar with one short reason. Never ask for passwords or confidential work data."
            val body = JSONObject()
                .put("model", model)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                .put("temperature", 0.4)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) "API error ${conn.responseCode}: ${raw.take(700)}"
            else {
                val json = JSONObject(raw)
                json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                    ?: "The API responded, but this endpoint's response format is not recognized."
            }
        } catch (e: Exception) {
            "Could not connect: ${e.message ?: "unknown error"}. Check internet, endpoint, model, and API key."
        }
    }
}
